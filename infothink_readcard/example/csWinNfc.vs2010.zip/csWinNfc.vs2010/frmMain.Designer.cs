﻿namespace csWinNfc
{
    partial class frmMain
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器
        /// 修改這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.btnDisConnect = new System.Windows.Forms.Button();
            this.btnDeSelect = new System.Windows.Forms.Button();
            this.GroupBox2 = new System.Windows.Forms.GroupBox();
            this.btnSelect = new System.Windows.Forms.Button();
            this.btnTest2 = new System.Windows.Forms.Button();
            this.btnTest1 = new System.Windows.Forms.Button();
            this.Label2 = new System.Windows.Forms.Label();
            this.lbMessage = new System.Windows.Forms.ListBox();
            this.Label1 = new System.Windows.Forms.Label();
            this.cbReader = new System.Windows.Forms.ComboBox();
            this.btnConnect = new System.Windows.Forms.Button();
            this.rbBuzzerON = new System.Windows.Forms.RadioButton();
            this.cbBlueLED = new System.Windows.Forms.CheckBox();
            this.cbRedLED = new System.Windows.Forms.CheckBox();
            this.rbBuzzerOFF = new System.Windows.Forms.RadioButton();
            this.GroupBox1 = new System.Windows.Forms.GroupBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnSend = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.txtAPDU = new System.Windows.Forms.TextBox();
            this.GroupBox2.SuspendLayout();
            this.GroupBox1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnDisConnect
            // 
            this.btnDisConnect.Enabled = false;
            this.btnDisConnect.Location = new System.Drawing.Point(322, 27);
            this.btnDisConnect.Name = "btnDisConnect";
            this.btnDisConnect.Size = new System.Drawing.Size(75, 23);
            this.btnDisConnect.TabIndex = 19;
            this.btnDisConnect.Text = "DisConnect";
            this.btnDisConnect.UseVisualStyleBackColor = true;
            this.btnDisConnect.Click += new System.EventHandler(this.btnDisConnect_Click);
            // 
            // btnDeSelect
            // 
            this.btnDeSelect.Enabled = false;
            this.btnDeSelect.Location = new System.Drawing.Point(87, 17);
            this.btnDeSelect.Name = "btnDeSelect";
            this.btnDeSelect.Size = new System.Drawing.Size(75, 23);
            this.btnDeSelect.TabIndex = 6;
            this.btnDeSelect.Text = "DSelect Card";
            this.btnDeSelect.UseVisualStyleBackColor = true;
            this.btnDeSelect.Click += new System.EventHandler(this.btnDeSelect_Click);
            // 
            // GroupBox2
            // 
            this.GroupBox2.Controls.Add(this.btnDeSelect);
            this.GroupBox2.Controls.Add(this.btnSelect);
            this.GroupBox2.Controls.Add(this.btnTest2);
            this.GroupBox2.Controls.Add(this.btnTest1);
            this.GroupBox2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.GroupBox2.Location = new System.Drawing.Point(220, 11);
            this.GroupBox2.Name = "GroupBox2";
            this.GroupBox2.Size = new System.Drawing.Size(170, 83);
            this.GroupBox2.TabIndex = 18;
            this.GroupBox2.TabStop = false;
            this.GroupBox2.Text = "Mifare";
            // 
            // btnSelect
            // 
            this.btnSelect.Enabled = false;
            this.btnSelect.Location = new System.Drawing.Point(6, 17);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(75, 23);
            this.btnSelect.TabIndex = 5;
            this.btnSelect.Text = "Select Card";
            this.btnSelect.UseVisualStyleBackColor = true;
            this.btnSelect.Click += new System.EventHandler(this.btnSelect_Click);
            // 
            // btnTest2
            // 
            this.btnTest2.Enabled = false;
            this.btnTest2.Location = new System.Drawing.Point(87, 51);
            this.btnTest2.Name = "btnTest2";
            this.btnTest2.Size = new System.Drawing.Size(75, 23);
            this.btnTest2.TabIndex = 2;
            this.btnTest2.Text = "Test 2";
            this.btnTest2.UseVisualStyleBackColor = true;
            this.btnTest2.Click += new System.EventHandler(this.btnTest2_Click);
            // 
            // btnTest1
            // 
            this.btnTest1.Enabled = false;
            this.btnTest1.Location = new System.Drawing.Point(6, 51);
            this.btnTest1.Name = "btnTest1";
            this.btnTest1.Size = new System.Drawing.Size(75, 23);
            this.btnTest1.TabIndex = 1;
            this.btnTest1.Text = "Test 1";
            this.btnTest1.UseVisualStyleBackColor = true;
            this.btnTest1.Click += new System.EventHandler(this.btnTest1_Click);
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Location = new System.Drawing.Point(10, 194);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(32, 12);
            this.Label2.TabIndex = 17;
            this.Label2.Text = "訊息:";
            // 
            // lbMessage
            // 
            this.lbMessage.FormattingEnabled = true;
            this.lbMessage.ItemHeight = 12;
            this.lbMessage.Location = new System.Drawing.Point(9, 211);
            this.lbMessage.Name = "lbMessage";
            this.lbMessage.Size = new System.Drawing.Size(403, 112);
            this.lbMessage.TabIndex = 16;
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Location = new System.Drawing.Point(12, 9);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(68, 12);
            this.Label1.TabIndex = 14;
            this.Label1.Text = "選擇讀卡機:";
            // 
            // cbReader
            // 
            this.cbReader.FormattingEnabled = true;
            this.cbReader.Items.AddRange(new object[] {
            "自動連線",
            "InfoThink IT-100MU 0",
            "InfoThink IT-100MU 1",
            "InfoThink IT-100MU 3",
            "InfoThink IT-100MU 4"});
            this.cbReader.Location = new System.Drawing.Point(11, 27);
            this.cbReader.Name = "cbReader";
            this.cbReader.Size = new System.Drawing.Size(211, 20);
            this.cbReader.TabIndex = 13;
            // 
            // btnConnect
            // 
            this.btnConnect.Location = new System.Drawing.Point(241, 27);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(75, 23);
            this.btnConnect.TabIndex = 12;
            this.btnConnect.Text = "Connect";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // rbBuzzerON
            // 
            this.rbBuzzerON.AutoSize = true;
            this.rbBuzzerON.Location = new System.Drawing.Point(13, 50);
            this.rbBuzzerON.Name = "rbBuzzerON";
            this.rbBuzzerON.Size = new System.Drawing.Size(75, 16);
            this.rbBuzzerON.TabIndex = 4;
            this.rbBuzzerON.Text = "Buzzer ON";
            this.rbBuzzerON.UseVisualStyleBackColor = true;
            this.rbBuzzerON.CheckedChanged += new System.EventHandler(this.rbBuzzerON_CheckedChanged);
            // 
            // cbBlueLED
            // 
            this.cbBlueLED.AutoSize = true;
            this.cbBlueLED.ForeColor = System.Drawing.Color.Blue;
            this.cbBlueLED.Location = new System.Drawing.Point(16, 24);
            this.cbBlueLED.Name = "cbBlueLED";
            this.cbBlueLED.Size = new System.Drawing.Size(70, 16);
            this.cbBlueLED.TabIndex = 5;
            this.cbBlueLED.Text = "藍色LED";
            this.cbBlueLED.UseVisualStyleBackColor = true;
            this.cbBlueLED.CheckedChanged += new System.EventHandler(this.cbBlueLED_CheckedChanged);
            // 
            // cbRedLED
            // 
            this.cbRedLED.AutoSize = true;
            this.cbRedLED.ForeColor = System.Drawing.Color.Red;
            this.cbRedLED.Location = new System.Drawing.Point(111, 24);
            this.cbRedLED.Name = "cbRedLED";
            this.cbRedLED.Size = new System.Drawing.Size(70, 16);
            this.cbRedLED.TabIndex = 6;
            this.cbRedLED.Text = "紅色LED";
            this.cbRedLED.UseVisualStyleBackColor = true;
            this.cbRedLED.CheckedChanged += new System.EventHandler(this.cbRedLED_CheckedChanged);
            // 
            // rbBuzzerOFF
            // 
            this.rbBuzzerOFF.AutoSize = true;
            this.rbBuzzerOFF.Checked = true;
            this.rbBuzzerOFF.Location = new System.Drawing.Point(111, 50);
            this.rbBuzzerOFF.Name = "rbBuzzerOFF";
            this.rbBuzzerOFF.Size = new System.Drawing.Size(79, 16);
            this.rbBuzzerOFF.TabIndex = 3;
            this.rbBuzzerOFF.TabStop = true;
            this.rbBuzzerOFF.Text = "Buzzer OFF";
            this.rbBuzzerOFF.UseVisualStyleBackColor = true;
            this.rbBuzzerOFF.CheckedChanged += new System.EventHandler(this.rbBuzzerOFF_CheckedChanged);
            // 
            // GroupBox1
            // 
            this.GroupBox1.Controls.Add(this.rbBuzzerON);
            this.GroupBox1.Controls.Add(this.cbBlueLED);
            this.GroupBox1.Controls.Add(this.cbRedLED);
            this.GroupBox1.Controls.Add(this.rbBuzzerOFF);
            this.GroupBox1.Location = new System.Drawing.Point(6, 13);
            this.GroupBox1.Name = "GroupBox1";
            this.GroupBox1.Size = new System.Drawing.Size(201, 81);
            this.GroupBox1.TabIndex = 15;
            this.GroupBox1.TabStop = false;
            this.GroupBox1.Text = "硬體控制";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(11, 57);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(405, 127);
            this.tabControl1.TabIndex = 20;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.GroupBox2);
            this.tabPage1.Controls.Add(this.GroupBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(397, 101);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "基本功能";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.txtAPDU);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.btnSend);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(397, 101);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "ISO14443";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // btnSend
            // 
            this.btnSend.Location = new System.Drawing.Point(307, 39);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(75, 23);
            this.btnSend.TabIndex = 13;
            this.btnSend.Text = "Send";
            this.btnSend.UseVisualStyleBackColor = true;
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(15, 21);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 12);
            this.label3.TabIndex = 14;
            this.label3.Text = "APDU Command:";
            // 
            // txtAPDU
            // 
            this.txtAPDU.Location = new System.Drawing.Point(17, 39);
            this.txtAPDU.Name = "txtAPDU";
            this.txtAPDU.Size = new System.Drawing.Size(284, 22);
            this.txtAPDU.TabIndex = 15;
            this.txtAPDU.Text = "00 A4 00 00 02 3F 00";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(424, 334);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.btnDisConnect);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.lbMessage);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.cbReader);
            this.Controls.Add(this.btnConnect);
            this.Name = "frmMain";
            this.Text = "InfoThink NFC C# example V1.7";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.GroupBox2.ResumeLayout(false);
            this.GroupBox1.ResumeLayout(false);
            this.GroupBox1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Button btnDisConnect;
        internal System.Windows.Forms.Button btnDeSelect;
        internal System.Windows.Forms.GroupBox GroupBox2;
        internal System.Windows.Forms.Button btnSelect;
        internal System.Windows.Forms.Button btnTest2;
        internal System.Windows.Forms.Button btnTest1;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.ListBox lbMessage;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.ComboBox cbReader;
        internal System.Windows.Forms.Button btnConnect;
        internal System.Windows.Forms.RadioButton rbBuzzerON;
        internal System.Windows.Forms.CheckBox cbBlueLED;
        internal System.Windows.Forms.CheckBox cbRedLED;
        internal System.Windows.Forms.RadioButton rbBuzzerOFF;
        internal System.Windows.Forms.GroupBox GroupBox1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        internal System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.TextBox txtAPDU;
        private System.Windows.Forms.Label label3;
    }
}

