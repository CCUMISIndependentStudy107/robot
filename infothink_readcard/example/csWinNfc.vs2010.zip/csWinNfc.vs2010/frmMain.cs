﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace csWinNfc
{
    public partial class frmMain : Form
    {
        int g_nCtx;

        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            cbReader.SelectedIndex = 0;
            g_nCtx = 0;

            int rc = WinNfc.NfcEstablishContext(0, 0, 0, ref g_nCtx);

            if (rc != 0)
            {
                WinNfc.ShowError(rc);
                return;
            }

            lbMessage.Items.Clear();
            EnableButton(false);
        }

        private void frmMain_Close(object sender, EventArgs e)
        {
            WinNfc.NfcReleaseContext(g_nCtx);
        }

        private void EnableButton(bool bEnable)
        {
            btnConnect.Enabled = !bEnable;
            btnDisConnect.Enabled = bEnable;
            cbRedLED.Enabled = bEnable;
            cbBlueLED.Enabled = bEnable;
            rbBuzzerON.Enabled = bEnable;
            rbBuzzerOFF.Enabled = bEnable;
        }

        private void EnableTestButton(bool bEnable)
        {
            btnSelect.Enabled = !bEnable;
            btnDeSelect.Enabled = bEnable;
            btnTest1.Enabled = bEnable;
            btnTest2.Enabled = bEnable;
            btnSend.Enabled = bEnable;
        }

        private void ShowMessage(string sMsg)
        {
            lbMessage.Items.Add(sMsg);
            lbMessage.SelectedIndex = lbMessage.Items.Count - 1;
        }


        /*
         *      GetReaderName
         */
        private String GetReaderName()
        {
            int rc = 0;
            int nLen = 0;

            //Get Lenght of Reader Name
            rc = WinNfc.NfcGetParameter(g_nCtx, WinNfc.NFC_PARAMETER_READER_NAME, null, ref nLen);

            nLen = nLen + 1;
            StringBuilder ReaderName = new StringBuilder("0", nLen + 1);
            rc = WinNfc.NfcGetParameter(g_nCtx, WinNfc.NFC_PARAMETER_READER_NAME, ReaderName, ref nLen);

            return ReaderName.ToString();
        }

        /*
         *      ConnectReader
         */
        private bool ConnectReader()
        {
            int rc = 0;
            if (cbReader.Text == "自動連線")
            {
                rc = WinNfc.NfcConnect(g_nCtx, null, 0);
            }
            else
            {
                rc = WinNfc.NfcConnect(g_nCtx, new StringBuilder(cbReader.Text), 0);
            }

            if (rc != 0)
            {
                WinNfc.ShowError(rc);
                return false;
            }

            ShowMessage("connect reader: " + GetReaderName() + " ok");

            EnableButton(true);
            EnableTestButton(false);

            return true;
        }

        /*
         *      DisConnectReader
         */
        private bool DisConnectReader()
        {
            int rc = 0;
            rc = WinNfc.NfcDisconnect(g_nCtx, 0);

            if (rc != 0)
            {
                WinNfc.ShowError(rc);
                return false;
            }

            ShowMessage("disconnect reader ok");

            EnableButton(false);
            EnableTestButton(false);
            btnSelect.Enabled = false;
            return true;
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            ConnectReader();
        }

        private void btnDisConnect_Click(object sender, EventArgs e)
        {
            DisConnectReader();
        }

        /*
         *      SetLED
         */
        private void SetLED()
        {
            int rc = 0;
            if (!cbRedLED.Checked && !cbBlueLED.Checked)
                rc = WinNfc.NfcLEDControl(g_nCtx, WinNfc.LEDEnum.全暗);

            if (!cbRedLED.Checked && cbBlueLED.Checked)
                rc = WinNfc.NfcLEDControl(g_nCtx, WinNfc.LEDEnum.藍燈);

            if (cbRedLED.Checked && !cbBlueLED.Checked)
                rc = WinNfc.NfcLEDControl(g_nCtx, WinNfc.LEDEnum.紅燈);

            if (cbRedLED.Checked && cbBlueLED.Checked)
                rc = WinNfc.NfcLEDControl(g_nCtx, WinNfc.LEDEnum.全亮);

            if (rc != 0)
            {
                WinNfc.ShowError(rc);
            }
        }

        /*
         *      EnableBuzzer
         */
        private void EnableBuzzer(bool bEnable)
        {
            int rc = 0;
            if (bEnable)
            {
                rc = WinNfc.NfcBuzzerControl(g_nCtx, WinNfc.BuzzerEnum.開啟);
            }
            else
            {
                rc = WinNfc.NfcBuzzerControl(g_nCtx, WinNfc.BuzzerEnum.關閉);
            }

            if (rc != 0)
            {
                WinNfc.ShowError(rc);
            }
        }

        private void cbBlueLED_CheckedChanged(object sender, EventArgs e)
        {
            SetLED();
        }

        private void cbRedLED_CheckedChanged(object sender, EventArgs e)
        {
            SetLED();
        }

        private void rbBuzzerON_CheckedChanged(object sender, EventArgs e)
        {
            if (rbBuzzerON.Checked)
                EnableBuzzer(true);
        }

        private void rbBuzzerOFF_CheckedChanged(object sender, EventArgs e)
        {
            if (rbBuzzerOFF.Checked)
               EnableBuzzer(false);
        }

        /*
         *      SelectCard
         */
        private bool SelectCard()
        {
            int rc = 0;
            byte InData = 0;

            rc = WinNfc.NfcSelectCard(g_nCtx, WinNfc.CardTypeEnum.MIFARE, ref InData, 0);

            if (rc != 0)
            {
                WinNfc.ShowError(rc);
                return false;
            }

            ShowMessage("select card ok");

            EnableTestButton(true);
            return true;
        }

        /*
         *      DeSelectCard
         */
        private bool DeSelectCard()
        {
            int rc = 0;

            rc = WinNfc.NfcDeSelectCard(g_nCtx);

            if (rc != 0)
            {
                WinNfc.ShowError(rc);
                return false;
            }

            ShowMessage("de-select card ok");

            EnableTestButton(false);
            return true;
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            SelectCard();
        }

        private void btnDeSelect_Click(object sender, EventArgs e)
        {
            DeSelectCard();
        }

        private void btnTest1_Click(object sender, EventArgs e)
        {
            int rc = 0;
            StringBuilder sCardID = new StringBuilder("0", 16);

            rc = Mifare.GetCardID(g_nCtx, sCardID);
            if (rc != 0)
            {
                WinNfc.ShowError(rc);
                return;
            }
            ShowMessage("get card id: " + sCardID.ToString());

            byte[] Key = { 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF };
            rc = Mifare.KeyAuthority(g_nCtx, 1, Mifare.KeyEnum.KeyA, Key);
            if (rc != 0)
            {
                WinNfc.ShowError(rc);
                return;
            }
            ShowMessage("verify key A ok");

            //Data Read / Write Test]
            byte[] Data = new byte[16];
            int nLen  = 0;
            rc = Mifare.ReadBlock(g_nCtx, 1, Data, ref nLen);
            if (rc != 0)
            {
                WinNfc.ShowError(rc);
                return;
            }
            ShowMessage("read block 1 ok");
            ShowMessage(BitConverter.ToString(Data));

            //Write Data
            byte[] Data2 = { 1, 2, 3, 4, 5, 6, 7, 8, 1, 2, 3, 4, 5, 6, 7, 8 };
            rc = Mifare.WriteBlock(g_nCtx, 1, Data2, 16);
            if (rc != 0)
            {
                WinNfc.ShowError(rc);
                return;
            }
            ShowMessage("Write block 1 ok");
            ShowMessage(BitConverter.ToString(Data2));
            
            //Verify Data
            byte[] Data3 = new byte[16];
            rc = Mifare.ReadBlock(g_nCtx, 1, Data3, ref nLen);
            if (rc != 0)
            {
                WinNfc.ShowError(rc);
                return;
            }
            ShowMessage("read block 1 ok");
            ShowMessage(BitConverter.ToString(Data3));

            if (Data2.SequenceEqual(Data3))
                ShowMessage("Veirfy Data ok");
            else
                ShowMessage("Veirfy Data fail");
        }

        private void btnTest2_Click(object sender, EventArgs e)
        {
            int rc = 0;
           
            //Write Value]
            rc = Mifare.WriteValue(g_nCtx, 1, 5000);
            if (rc != 0)
            {
                WinNfc.ShowError(rc);
                return;
            }
            ShowMessage("write value 5000 ok");

            //Read Value
            int nValue = 0;
            rc = Mifare.ReadValue(g_nCtx, 1, ref nValue);
            if (rc != 0)
            {
                WinNfc.ShowError(rc);
                return;
            }
            ShowMessage("now Balance is " + nValue);

            //add value 200
            rc = Mifare.IncreaseValue(g_nCtx, 1, 200);
            if (rc != 0)
            {
                WinNfc.ShowError(rc);
                return;
            }
            ShowMessage("add 200 ok");

            rc = Mifare.TransferValue(g_nCtx, 1);
            if (rc != 0)
            {
                WinNfc.ShowError(rc);
                return;
            }

            nValue = 0;
            rc = Mifare.ReadValue(g_nCtx, 1, ref nValue);
            if (rc != 0)
            {
                WinNfc.ShowError(rc);
                return;
            }
            ShowMessage("now Balance is " + nValue);

            //remove value 100
            rc = Mifare.DecreaseValue(g_nCtx, 1, 100);
            if (rc != 0)
            {
                WinNfc.ShowError(rc);
                return;
            }
            ShowMessage("pay 100 ok");

            rc = Mifare.TransferValue(g_nCtx, 1);
            if (rc != 0)
            {
                WinNfc.ShowError(rc);
                return;
            }

            nValue = 0;
            rc = Mifare.ReadValue(g_nCtx, 1, ref nValue);
            if (rc != 0)
            {
                WinNfc.ShowError(rc);
                return;
            }
            ShowMessage("now Balance is " + nValue);

        }

        private byte[] FromHexString(string strInput)
        {
            // i variable used to hold position in string  
            int i = 0;
            // x variable used to hold byte array element position  
            int x = 0;
            // allocate byte array based on half of string length  
            byte[] bytes = new byte[(strInput.Length) / 2];
            // loop through the string - 2 bytes at a time converting it to decimal equivalent
            // and store in byte array  
            while (strInput.Length > i + 1)
            {
                long lngDecimal = Convert.ToInt32(strInput.Substring(i, 2), 16);
                bytes[x] = Convert.ToByte(lngDecimal);
                i = i + 2;
                ++x;
            }
            // return the finished byte array of decimal values  
            return bytes;
        }

        private string ToHexString(byte[] Data, int Len = 0)
        {
            // convert the byte array back to a true string  
            if (Len == 0)
                Len = Data.GetUpperBound(0) + 1;

            string strTemp = "";
            for (int x = 0; x < Len; x++)
            {
                int number = int.Parse(Data[x].ToString());
                strTemp += " " + number.ToString("X").PadLeft(2, '0');
            }
            // return the finished string of hex values  
            return strTemp;
        }  
        private void btnSend_Click(object sender, EventArgs e)
        {
            int rc = 0;
            byte[] Cmd = FromHexString(txtAPDU.Text.Replace(" ", ""));
            byte[] Data = new byte[255];
            int nLen = 255;

            ShowMessage("Send:" + ToHexString(Cmd));
            rc = ISO14443.SendAPDU(g_nCtx, Cmd, Cmd.Length, Data, ref nLen);
            if (rc != 0)
            {
                WinNfc.ShowError(rc);
                return;
            }
            ShowMessage("Recv:" + ToHexString(Data, nLen));
        }


    }
}
