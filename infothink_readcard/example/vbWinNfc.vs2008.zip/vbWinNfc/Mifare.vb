﻿Module Mifare

    Declare Ansi Function GetCardID Lib "WinNfc.dll" Alias "Mifare_GetCardID" ( _
    ByVal Context As Integer, _
    ByVal ID As String) _
    As Integer

    Declare Ansi Function KeyAuthority Lib "WinNfc.dll" Alias "Mifare_KeyAuthority" ( _
    ByVal Context As Integer, _
    ByVal Block As Integer, _
    ByVal KeyType As Integer, _
    ByVal Key As Byte()) _
    As Integer

    Declare Ansi Function ReadBlock Lib "WinNfc.dll" Alias "Mifare_ReadBlock" ( _
    ByVal Context As Integer, _
    ByVal Block As Integer, _
    ByVal Data As Byte(), _
    ByRef DataLen As Integer) _
    As Integer

    Declare Ansi Function WriteBlock Lib "WinNfc.dll" Alias "Mifare_WriteBlock" ( _
    ByVal Context As Integer, _
    ByVal Block As Integer, _
    ByVal Data As Byte(), _
    ByVal DataLen As Integer) _
    As Integer

    Declare Ansi Function ReadValue Lib "WinNfc.dll" Alias "Mifare_ReadValue" ( _
    ByVal Context As Integer, _
    ByVal Block As Integer, _
    ByRef Value As Integer) _
    As Integer

    Declare Ansi Function WriteValue Lib "WinNfc.dll" Alias "Mifare_WriteValue" ( _
    ByVal Context As Integer, _
    ByVal Block As Integer, _
    ByVal Value As Integer) _
    As Integer

    Declare Ansi Function IncreaseValue Lib "WinNfc.dll" Alias "Mifare_IncreaseValue" ( _
    ByVal Context As Integer, _
    ByVal Block As Integer, _
    ByVal Value As Integer) _
    As Integer

    Declare Ansi Function DecreaseValue Lib "WinNfc.dll" Alias "Mifare_DecreaseValue" ( _
    ByVal Context As Integer, _
    ByVal Block As Integer, _
    ByVal Value As Integer) _
    As Integer

    Declare Ansi Function TransferValue Lib "WinNfc.dll" Alias "Mifare_TransferValue" ( _
    ByVal Context As Integer, _
    ByVal Block As Integer) _
    As Integer

    Declare Ansi Function RestoreValue Lib "WinNfc.dll" Alias "Mifare_RestoreValue" ( _
    ByVal Context As Integer, _
    ByVal Block As Integer) _
    As Integer

End Module
