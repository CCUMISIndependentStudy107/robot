﻿Module WinNfc

    Public Enum ErrorEnum
        內部錯誤 = &H80100001
        傳入的Handle值錯誤 = &H80100003
        傳入參數錯誤 = &H80100004
        記憶體不足 = &H80100006
        無法辨識的讀卡機 = &H80100009
        函式逾時 = &H8010000A
        找不到卡片 = &H8010000C
        無法辨識的卡片 = &H8010000D
        傳入參數值錯誤 = &H80100011
        未知型錯誤 = &H80100014
        目前無法存取讀卡機 = &H80100017
        不支援的讀卡機 = &H8010001A
        不支援的卡片 = &H8010001C
        找不到讀卡機 = &H8010002E
    End Enum


    Public Enum CardTypeEnum
        ACTIVE_106 = &H1
        ACTIVE_212 = &H2
        ACTIVE_424 = &H4
        PASSIVE_106 = &H8
        PASSIVE_212 = &H10
        PASSIVE_424 = &H20
        MIFARE = &H40
        ISO14443_4A = &H80
        FELICA_212 = &H100
        FELICA_424 = &H200
        ISO14443_4B = &H400
        JEWEL = &H800
    End Enum


    Public Enum LEDEnum
        全暗 = &H0
        紅燈 = &H1
        藍燈 = &H2
        全亮 = &H3
    End Enum

    Public Enum BuzzerEnum
        開啟 = &H0
        關閉 = &H8
    End Enum


    '  Declare Ansi Function Thing Lib "thing1.dll" (ByVal Command As String, ByRef Buffer As StringBuilder, ByRef BufferLength As Integer) As Integer

    Declare Ansi Function NfcEstablishContext Lib "WinNfc.dll" Alias "NfcEstablishContext" ( _
    ByVal Scope As Integer, _
    ByVal Rev1 As Integer, _
    ByVal Rev2 As Integer, _
    ByRef Context As Integer) _
    As Integer

    Declare Ansi Function NfcReleaseContext Lib "WinNfc.dll" Alias "NfcReleaseContext" ( _
    ByVal Context As Integer) _
    As Integer


    Declare Ansi Function NfcConnect Lib "WinNfc.dll" Alias "NfcConnect" ( _
    ByVal Context As Integer, _
    ByVal ReaderName As String, _
    ByVal ShareMode As Integer) _
    As Integer

    Declare Ansi Function NfcDisconnect Lib "WinNfc.dll" Alias "NfcDisconnect" ( _
    ByVal Context As Integer, _
    ByVal Disposition As Integer) _
    As Integer


    Declare Ansi Function NfcSelectCard Lib "WinNfc.dll" Alias "NfcSelectCard" ( _
    ByVal Context As Integer, _
    ByVal CardType As Integer, _
    ByVal InitData As String, _
    ByVal InitDataLen As Integer) _
    As Integer

    Declare Ansi Function NfcDeSelectCard Lib "WinNfc.dll" Alias "NfcDeSelectCard" ( _
    ByVal Context As Integer) _
    As Integer

    Declare Ansi Function NfcLEDControl Lib "WinNfc.dll" Alias "NfcLEDControl" ( _
    ByVal Context As Integer, _
    ByVal State As LEDEnum) _
    As Integer

    Declare Ansi Function NfcBuzzerControl Lib "WinNfc.dll" Alias "NfcBuzzerControl" ( _
    ByVal Context As Integer, _
    ByVal State As BuzzerEnum) _
    As Integer



    Public Sub ShowError(ByVal nRc As Integer)
        Dim nError As ErrorEnum = nRc
        Dim sMsg As String = nError.ToString

        If sMsg = CStr(nRc) Then
            sMsg = "系統錯誤(" & nRc & ")"
        End If

        MsgBox(sMsg, MsgBoxStyle.Critical)

    End Sub


End Module
