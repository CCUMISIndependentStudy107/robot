﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form 覆寫 Dispose 以清除元件清單。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    '為 Windows Form 設計工具的必要項
    Private components As System.ComponentModel.IContainer

    '注意: 以下為 Windows Form 設計工具所需的程序
    '可以使用 Windows Form 設計工具進行修改。
    '請不要使用程式碼編輯器進行修改。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnConnect = New System.Windows.Forms.Button()
        Me.cbReader = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lbMessage = New System.Windows.Forms.ListBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnDisConnect = New System.Windows.Forms.Button()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.rbBuzzerON = New System.Windows.Forms.RadioButton()
        Me.cbBlueLED = New System.Windows.Forms.CheckBox()
        Me.cbRedLED = New System.Windows.Forms.CheckBox()
        Me.rbBuzzerOFF = New System.Windows.Forms.RadioButton()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.btnDeSelect = New System.Windows.Forms.Button()
        Me.btnSelect = New System.Windows.Forms.Button()
        Me.btnTest2 = New System.Windows.Forms.Button()
        Me.btnTest1 = New System.Windows.Forms.Button()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.txtAPDU = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btnSend = New System.Windows.Forms.Button()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnConnect
        '
        Me.btnConnect.Location = New System.Drawing.Point(244, 34)
        Me.btnConnect.Name = "btnConnect"
        Me.btnConnect.Size = New System.Drawing.Size(75, 23)
        Me.btnConnect.TabIndex = 0
        Me.btnConnect.Text = "Connect"
        Me.btnConnect.UseVisualStyleBackColor = True
        '
        'cbReader
        '
        Me.cbReader.FormattingEnabled = True
        Me.cbReader.Items.AddRange(New Object() {"自動連線", "InfoThink IT-100MU 0", "InfoThink IT-100MU 1", "InfoThink IT-100MU 3", "InfoThink IT-100MU 4"})
        Me.cbReader.Location = New System.Drawing.Point(12, 34)
        Me.cbReader.Name = "cbReader"
        Me.cbReader.Size = New System.Drawing.Size(211, 20)
        Me.cbReader.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(13, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(68, 12)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "選擇讀卡機:"
        '
        'lbMessage
        '
        Me.lbMessage.FormattingEnabled = True
        Me.lbMessage.ItemHeight = 12
        Me.lbMessage.Location = New System.Drawing.Point(12, 225)
        Me.lbMessage.Name = "lbMessage"
        Me.lbMessage.Size = New System.Drawing.Size(408, 112)
        Me.lbMessage.TabIndex = 8
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(13, 208)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(32, 12)
        Me.Label2.TabIndex = 9
        Me.Label2.Text = "訊息:"
        '
        'btnDisConnect
        '
        Me.btnDisConnect.Enabled = False
        Me.btnDisConnect.Location = New System.Drawing.Point(325, 34)
        Me.btnDisConnect.Name = "btnDisConnect"
        Me.btnDisConnect.Size = New System.Drawing.Size(75, 23)
        Me.btnDisConnect.TabIndex = 11
        Me.btnDisConnect.Text = "DisConnect"
        Me.btnDisConnect.UseVisualStyleBackColor = True
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Location = New System.Drawing.Point(12, 63)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(408, 134)
        Me.TabControl1.TabIndex = 12
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.GroupBox1)
        Me.TabPage1.Controls.Add(Me.GroupBox2)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(400, 108)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "基本功能"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rbBuzzerON)
        Me.GroupBox1.Controls.Add(Me.cbBlueLED)
        Me.GroupBox1.Controls.Add(Me.cbRedLED)
        Me.GroupBox1.Controls.Add(Me.rbBuzzerOFF)
        Me.GroupBox1.Location = New System.Drawing.Point(6, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(201, 81)
        Me.GroupBox1.TabIndex = 12
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "硬體控制"
        '
        'rbBuzzerON
        '
        Me.rbBuzzerON.AutoSize = True
        Me.rbBuzzerON.Location = New System.Drawing.Point(13, 50)
        Me.rbBuzzerON.Name = "rbBuzzerON"
        Me.rbBuzzerON.Size = New System.Drawing.Size(75, 16)
        Me.rbBuzzerON.TabIndex = 4
        Me.rbBuzzerON.Text = "Buzzer ON"
        Me.rbBuzzerON.UseVisualStyleBackColor = True
        '
        'cbBlueLED
        '
        Me.cbBlueLED.AutoSize = True
        Me.cbBlueLED.ForeColor = System.Drawing.Color.Blue
        Me.cbBlueLED.Location = New System.Drawing.Point(16, 24)
        Me.cbBlueLED.Name = "cbBlueLED"
        Me.cbBlueLED.Size = New System.Drawing.Size(70, 16)
        Me.cbBlueLED.TabIndex = 5
        Me.cbBlueLED.Text = "藍色LED"
        Me.cbBlueLED.UseVisualStyleBackColor = True
        '
        'cbRedLED
        '
        Me.cbRedLED.AutoSize = True
        Me.cbRedLED.ForeColor = System.Drawing.Color.Red
        Me.cbRedLED.Location = New System.Drawing.Point(111, 24)
        Me.cbRedLED.Name = "cbRedLED"
        Me.cbRedLED.Size = New System.Drawing.Size(70, 16)
        Me.cbRedLED.TabIndex = 6
        Me.cbRedLED.Text = "紅色LED"
        Me.cbRedLED.UseVisualStyleBackColor = True
        '
        'rbBuzzerOFF
        '
        Me.rbBuzzerOFF.AutoSize = True
        Me.rbBuzzerOFF.Location = New System.Drawing.Point(111, 50)
        Me.rbBuzzerOFF.Name = "rbBuzzerOFF"
        Me.rbBuzzerOFF.Size = New System.Drawing.Size(79, 16)
        Me.rbBuzzerOFF.TabIndex = 3
        Me.rbBuzzerOFF.Text = "Buzzer OFF"
        Me.rbBuzzerOFF.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.btnDeSelect)
        Me.GroupBox2.Controls.Add(Me.btnSelect)
        Me.GroupBox2.Controls.Add(Me.btnTest2)
        Me.GroupBox2.Controls.Add(Me.btnTest1)
        Me.GroupBox2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.GroupBox2.Location = New System.Drawing.Point(222, 12)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(170, 83)
        Me.GroupBox2.TabIndex = 11
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Mifare"
        '
        'btnDeSelect
        '
        Me.btnDeSelect.Enabled = False
        Me.btnDeSelect.Location = New System.Drawing.Point(87, 17)
        Me.btnDeSelect.Name = "btnDeSelect"
        Me.btnDeSelect.Size = New System.Drawing.Size(75, 23)
        Me.btnDeSelect.TabIndex = 6
        Me.btnDeSelect.Text = "DSelect Card"
        Me.btnDeSelect.UseVisualStyleBackColor = True
        '
        'btnSelect
        '
        Me.btnSelect.Enabled = False
        Me.btnSelect.Location = New System.Drawing.Point(6, 17)
        Me.btnSelect.Name = "btnSelect"
        Me.btnSelect.Size = New System.Drawing.Size(75, 23)
        Me.btnSelect.TabIndex = 5
        Me.btnSelect.Text = "Select Card"
        Me.btnSelect.UseVisualStyleBackColor = True
        '
        'btnTest2
        '
        Me.btnTest2.Enabled = False
        Me.btnTest2.Location = New System.Drawing.Point(87, 51)
        Me.btnTest2.Name = "btnTest2"
        Me.btnTest2.Size = New System.Drawing.Size(75, 23)
        Me.btnTest2.TabIndex = 2
        Me.btnTest2.Text = "Test 2"
        Me.btnTest2.UseVisualStyleBackColor = True
        '
        'btnTest1
        '
        Me.btnTest1.Enabled = False
        Me.btnTest1.Location = New System.Drawing.Point(6, 51)
        Me.btnTest1.Name = "btnTest1"
        Me.btnTest1.Size = New System.Drawing.Size(75, 23)
        Me.btnTest1.TabIndex = 1
        Me.btnTest1.Text = "Test 1"
        Me.btnTest1.UseVisualStyleBackColor = True
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.txtAPDU)
        Me.TabPage3.Controls.Add(Me.Label3)
        Me.TabPage3.Controls.Add(Me.btnSend)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(400, 108)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "ISO14443"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'txtAPDU
        '
        Me.txtAPDU.Location = New System.Drawing.Point(16, 39)
        Me.txtAPDU.Name = "txtAPDU"
        Me.txtAPDU.Size = New System.Drawing.Size(281, 22)
        Me.txtAPDU.TabIndex = 2
        Me.txtAPDU.Text = "00 A4 00 00 02 3F 00"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(14, 24)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(90, 12)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "APDU Command:"
        '
        'btnSend
        '
        Me.btnSend.Location = New System.Drawing.Point(309, 39)
        Me.btnSend.Name = "btnSend"
        Me.btnSend.Size = New System.Drawing.Size(75, 23)
        Me.btnSend.TabIndex = 0
        Me.btnSend.Text = "Send"
        Me.btnSend.UseVisualStyleBackColor = True
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(431, 350)
        Me.Controls.Add(Me.btnDisConnect)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lbMessage)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.cbReader)
        Me.Controls.Add(Me.btnConnect)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "frmMain"
        Me.Text = "InfoThink NFC VB example V1.7"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnConnect As System.Windows.Forms.Button
    Friend WithEvents cbReader As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lbMessage As System.Windows.Forms.ListBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents btnDisConnect As System.Windows.Forms.Button
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents rbBuzzerON As System.Windows.Forms.RadioButton
    Friend WithEvents cbBlueLED As System.Windows.Forms.CheckBox
    Friend WithEvents cbRedLED As System.Windows.Forms.CheckBox
    Friend WithEvents rbBuzzerOFF As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents btnDeSelect As System.Windows.Forms.Button
    Friend WithEvents btnSelect As System.Windows.Forms.Button
    Friend WithEvents btnTest2 As System.Windows.Forms.Button
    Friend WithEvents btnTest1 As System.Windows.Forms.Button
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents btnSend As System.Windows.Forms.Button
    Friend WithEvents txtAPDU As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label

End Class
