﻿Public Class frmMain

    Private g_nCtx As Integer

    Private Sub frnMain_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        cbReader.SelectedIndex = 0
        g_nCtx = 0

        Dim nRc As Integer

        nRc = WinNfc.NfcEstablishContext(0, 0, 0, g_nCtx)

        If (nRc) Then
            ShowError(nRc)
            Exit Sub
        End If

        lbMessage.Items.Clear()
        EnableButton(False)
    End Sub

    Private Sub frnMain_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        WinNfc.NfcReleaseContext(g_nCtx)
    End Sub

    Sub EnableButton(ByVal bEnable As Boolean)
        btnConnect.Enabled = Not bEnable
        btnDisConnect.Enabled = bEnable
        'btnSelect.Enabled = bEnable
        'btnDeSelect.Enabled = bEnable
        cbRedLED.Enabled = bEnable
        cbBlueLED.Enabled = bEnable
        rbBuzzerON.Enabled = bEnable
        rbBuzzerOFF.Enabled = bEnable
    End Sub

    Sub ShowMessage(ByVal sMsg As String)

        lbMessage.Items.Add(sMsg)
        lbMessage.SelectedIndex = lbMessage.Items.Count - 1
    End Sub


    Function GetReaderName() As String
        Dim nRc As Integer

        Dim Len As Integer = 0
        nRc = WinNfc.NfcGetParameter(g_nCtx, WinNfc.NFC_PARAMETER_READER_NAME, vbNullString, Len)

        If (nRc) Then
            ShowError(nRc)
            Return ""
        End If

        Len = Len + 1
        Dim sReaderName As String = Space$(Len)
        nRc = WinNfc.NfcGetParameter(g_nCtx, WinNfc.NFC_PARAMETER_READER_NAME, sReaderName, Len)

        If (nRc) Then
            ShowError(nRc)
            Return ""
        End If

        Return sReaderName
    End Function

    Function ConnectReader() As Boolean
        Dim nRc As Integer

        If cbReader.Text = "自動連線" Then
            nRc = WinNfc.NfcConnect(g_nCtx, vbNullString, 0)
        Else
            nRc = WinNfc.NfcConnect(g_nCtx, cbReader.Text, 0)
        End If

        If (nRc) Then
            ShowError(nRc)
            Return False
        End If

        ShowMessage("connect reader:" & GetReaderName() & " ok")

        EnableButton(True)
        EnableTestButton(False)

        Return True
    End Function

    Function DisConnectReader() As Boolean
        Dim nRc As Integer
        nRc = WinNfc.NfcDisconnect(g_nCtx, 0)
        If (nRc) Then
            ShowError(nRc)
            Return False
        End If
        ShowMessage("disconnect reader ok")

        EnableButton(False)
        EnableTestButton(False)
        btnSelect.Enabled = False
        Return True
    End Function

    Private Sub btnConnect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnConnect.Click
        ConnectReader()
    End Sub


    Private Sub btnDisConnect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDisConnect.Click
        DisConnectReader()
    End Sub

    Sub SetLED()
        Dim nRc As Integer

        If cbRedLED.Checked = False And cbBlueLED.Checked = False Then
            nRc = WinNfc.NfcLEDControl(g_nCtx, LEDEnum.全暗)
            If (nRc) Then
                ShowError(nRc)
                Exit Sub
            End If
        End If

        If cbRedLED.Checked = False And cbBlueLED.Checked = True Then
            nRc = WinNfc.NfcLEDControl(g_nCtx, LEDEnum.藍燈)
            If (nRc) Then
                ShowError(nRc)
                Exit Sub
            End If
        End If

        If cbRedLED.Checked = True And cbBlueLED.Checked = False Then
            nRc = WinNfc.NfcLEDControl(g_nCtx, LEDEnum.紅燈)
            If (nRc) Then
                ShowError(nRc)
                Exit Sub
            End If
        End If


        If cbRedLED.Checked = True And cbBlueLED.Checked = True Then
            nRc = WinNfc.NfcLEDControl(g_nCtx, LEDEnum.全亮)
            If (nRc) Then
                ShowError(nRc)
                Exit Sub
            End If
        End If
    End Sub

    Sub EnableBuzzer(ByVal bEnable As Boolean)
        Dim nRc As Integer
        If bEnable Then
            nRc = WinNfc.NfcBuzzerControl(g_nCtx, BuzzerEnum.開啟)
            If (nRc) Then
                ShowError(nRc)
                Exit Sub
            End If
        Else
            nRc = WinNfc.NfcBuzzerControl(g_nCtx, BuzzerEnum.關閉)

            If (nRc) Then
                ShowError(nRc)
                Exit Sub
            End If
        End If

    End Sub



    Private Sub cbBlueLED_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbBlueLED.CheckedChanged
        SetLED()
    End Sub

    Private Sub cbRedLED_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbRedLED.CheckedChanged
        SetLED()
    End Sub

    Private Sub rbBuzzerON_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles rbBuzzerON.CheckedChanged
        EnableBuzzer(True)
    End Sub

    Private Sub rbBuzzerOFF_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles rbBuzzerOFF.CheckedChanged
        EnableBuzzer(False)
    End Sub


    Sub EnableTestButton(ByVal bEnable As Boolean)
        btnSelect.Enabled = Not bEnable
        btnDeSelect.Enabled = bEnable
        btnTest1.Enabled = bEnable
        btnTest2.Enabled = bEnable
        btnSend.Enabled = bEnable
    End Sub

    Function SelectCard() As Boolean
        Dim nRc As Integer

        nRc = WinNfc.NfcSelectCard(g_nCtx, CardTypeEnum.MIFARE, vbNullChar, 0)

        If (nRc) Then
            ShowError(nRc)
            Return False
        End If

        ShowMessage("select card ok")

        EnableTestButton(True)
        Return True
    End Function

    Function DeSelectCard() As Boolean
        Dim nRc As Integer
        nRc = WinNfc.NfcDeSelectCard(g_nCtx)
        If (nRc) Then
            ShowError(nRc)
            Return False
        End If
        ShowMessage("de-select card ok")

        EnableTestButton(False)
        Return True
    End Function

    Private Sub btnSelect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSelect.Click
        SelectCard()
    End Sub

    Private Sub btnDeSelect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDeSelect.Click
        DeSelectCard()
    End Sub

    Private Sub btnTest1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTest1.Click
        Dim nRc As Integer
        Dim sCardID As String = Space$(16)

        nRc = Mifare.GetCardID(g_nCtx, sCardID)
        If (nRc) Then
            ShowError(nRc)
            Exit Sub
        End If

        ShowMessage("get card id: " & sCardID)

        Dim Key() As Byte = {255, 255, 255, 255, 255, 255}

        nRc = Mifare.KeyAuthority(g_nCtx, 1, KeyEnum.KeyA, Key)
        If (nRc) Then
            ShowError(nRc)
            Exit Sub
        End If
        ShowMessage("verify key A ok")

        'Data Read / Write Test
        Dim Data(15) As Byte
        Dim nLen As Integer = 0
        nRc = Mifare.ReadBlock(g_nCtx, 1, Data, nLen)
        If (nRc) Then
            ShowError(nRc)
            Exit Sub
        End If
        ShowMessage("read block 1 ok")
        ShowMessage(BitConverter.ToString(Data))

        Dim Data2() As Byte = {1, 2, 3, 4, 5, 6, 7, 8, 1, 2, 3, 4, 5, 6, 7, 8}
        nRc = Mifare.WriteBlock(g_nCtx, 1, Data2, 16)
        If (nRc) Then
            ShowError(nRc)
            Exit Sub
        End If
        ShowMessage("write block 1 ok")
        ShowMessage(BitConverter.ToString(Data2))

        Dim Data3(15) As Byte
        nRc = Mifare.ReadBlock(g_nCtx, 1, Data3, nLen)
        If (nRc) Then
            ShowError(nRc)
            Exit Sub
        End If

        ShowMessage("read block 1 ok")
        ShowMessage(BitConverter.ToString(Data3))

    End Sub

    Private Sub btnTest2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTest2.Click
        Dim nRc As Integer

        nRc = Mifare.WriteValue(g_nCtx, 1, 5000)
        If (nRc) Then
            ShowError(nRc)
            Exit Sub
        End If
        ShowMessage("write value 5000 ok")

        Dim nValue As Integer = 0
        nRc = Mifare.ReadValue(g_nCtx, 1, nValue)
        If (nRc) Then
            ShowError(nRc)
            Exit Sub
        End If
        ShowMessage("now Balance is " & nValue)

        '加值 200
        nRc = Mifare.IncreaseValue(g_nCtx, 1, 200)
        If (nRc) Then
            ShowError(nRc)
            Exit Sub
        End If
        ShowMessage("add 200 ok")

        nRc = Mifare.TransferValue(g_nCtx, 1)
        If (nRc) Then
            ShowError(nRc)
            Exit Sub
        End If

        nValue = 0
        nRc = Mifare.ReadValue(g_nCtx, 1, nValue)
        If (nRc) Then
            ShowError(nRc)
            Exit Sub
        End If
        ShowMessage("now Balance is " & nValue)

        '扣款 100
        nRc = Mifare.DecreaseValue(g_nCtx, 1, 100)
        If (nRc) Then
            ShowError(nRc)
            Exit Sub
        End If
        ShowMessage("pay 100 ok")

        nRc = Mifare.TransferValue(g_nCtx, 1)
        If (nRc) Then
            ShowError(nRc)
            Exit Sub
        End If

        nValue = 0
        nRc = Mifare.ReadValue(g_nCtx, 1, nValue)
        If (nRc) Then
            ShowError(nRc)
            Exit Sub
        End If
        ShowMessage("now Balance is " & nValue)

    End Sub

    Public Function ToHexString(Data() As Byte, Optional Len As Integer = 0) As String
        Dim hexStr As String = ""
        Dim i As Integer

        If Len = 0 Then
            Len = Data.Length
        End If

        For i = 0 To Len - 1
            hexStr = hexStr & " " & Hex(Data(i)).PadLeft(2, "0")
        Next (i)
        Return hexStr
    End Function

    Public Function FromHexString(ByVal data As String) As Byte()
        Dim sendData As Byte() = New Byte((data.Length / 2) - 1) {}
        For i As Integer = 0 To (sendData.Length - 1)
            sendData(i) = CByte(Convert.ToInt32(data.Substring(i * 2, 2), 16))
        Next i
        Return sendData
    End Function

    Private Sub btnSend_Click(sender As System.Object, e As System.EventArgs) Handles btnSend.Click
        Dim nRc As Integer

        Dim cmd() As Byte = FromHexString(txtAPDU.Text.Replace(" ", "").ToString)
        Dim n As Integer = cmd.GetUpperBound(0)

        Dim Data(255) As Byte
        Dim nLen As Integer = 255
        Dim nActive As Integer = 0

        ShowMessage("Send:" & ToHexString(cmd))
        nRc = ISO14443.SendAPDU(g_nCtx, cmd, cmd.GetUpperBound(0) + 1, Data, nLen)

        If (nRc) Then
            ShowError(nRc)
            Exit Sub
        End If

        ShowMessage("Recv:" & ToHexString(Data, nLen))

    End Sub
End Class
